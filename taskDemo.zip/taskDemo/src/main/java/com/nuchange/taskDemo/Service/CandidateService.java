package com.nuchange.taskDemo.Service;

import com.nuchange.taskDemo.Model.Candidate;
import com.nuchange.taskDemo.Repository.CandidateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CandidateService {

    private final CandidateRepository candidateRepository;

    @Autowired
    public CandidateService(CandidateRepository candidateRepository) {
        this.candidateRepository = candidateRepository;
    }

    public void enterCandidate(String name) {
        Candidate candidate = new Candidate();
        candidate.setName(name);
        candidate.setVoteCount(0);
        candidateRepository.save(candidate);
    }

    public int castVote(String name) {
        Candidate candidate = candidateRepository.findById(name).orElseThrow();
        candidate.setVoteCount(candidate.getVoteCount() + 1);
        candidateRepository.save(candidate);
        return candidate.getVoteCount();
    }

    public int countVote(String name) {
        Candidate candidate = candidateRepository.findById(name).orElseThrow();
        return candidate.getVoteCount();
    }

    public List<Candidate> listVotes() {
        return candidateRepository.findAll();
    }

    public String getWinner() {
        List<Candidate> candidates = candidateRepository.findAll();
        if (candidates.isEmpty()) {
            return "No candidates available";
        }
        Candidate winner = candidates.stream().max((c1, c2) -> Integer.compare(c1.getVoteCount(), c2.getVoteCount())).orElseThrow();
        return winner.getName();
    }
}


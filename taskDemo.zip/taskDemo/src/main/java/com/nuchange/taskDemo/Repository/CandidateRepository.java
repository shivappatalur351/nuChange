package com.nuchange.taskDemo.Repository;

import com.nuchange.taskDemo.Model.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandidateRepository extends JpaRepository<Candidate, String> {
}


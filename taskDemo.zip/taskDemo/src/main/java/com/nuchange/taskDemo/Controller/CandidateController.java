package com.nuchange.taskDemo.Controller;
import com.nuchange.taskDemo.Model.Candidate;
import com.nuchange.taskDemo.Service.CandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CandidateController {

    private final CandidateService candidateService;

    @Autowired
    public CandidateController(CandidateService candidateService) {
        this.candidateService = candidateService;
    }

    @PostMapping("/entercandidate")
    public void enterCandidate(@RequestParam String name) {
        candidateService.enterCandidate(name);
    }

    @PostMapping("/castvote")
    public int castVote(@RequestParam String name) {
        return candidateService.castVote(name);
    }

    @GetMapping("/countvote")
    public int countVote(@RequestParam String name) {
        return candidateService.countVote(name);
    }

    @GetMapping("/listvote")
    public List<Candidate> listVotes() {
        return candidateService.listVotes();
    }

    @GetMapping("/getwinner")
    public String getWinner() {
        return candidateService.getWinner();
    }
}

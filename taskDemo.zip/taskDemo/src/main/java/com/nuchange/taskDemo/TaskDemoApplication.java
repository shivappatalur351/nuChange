package com.nuchange.taskDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskDemoApplication.class, args);
	}

}

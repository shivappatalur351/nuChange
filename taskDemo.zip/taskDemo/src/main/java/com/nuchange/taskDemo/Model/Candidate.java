package com.nuchange.taskDemo.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Getter
@Entity
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Candidate")
public class Candidate {
    @Id
    private String name;
    private int voteCount;

    // Constructors, getters, and setters
}

